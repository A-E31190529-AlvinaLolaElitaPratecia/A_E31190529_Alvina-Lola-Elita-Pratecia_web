<?php
//set the class model name
$sportsCar1 -> setModel ('Mercedes Benz');

//get the class model name 
echo $sportsCar1-> hello ();
?>
