<?php
interface Car {
	public function setModel ($name);

	public function getModel ();
}
?>