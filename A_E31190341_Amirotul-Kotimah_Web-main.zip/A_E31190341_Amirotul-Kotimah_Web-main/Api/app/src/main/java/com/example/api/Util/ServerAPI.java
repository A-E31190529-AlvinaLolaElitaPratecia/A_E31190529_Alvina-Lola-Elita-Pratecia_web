package com.example.api.Util;

public class ServerAPI {
    public static final String URL_DATA = "http://192.168.43.72/Minggu14/Mahasiswa/Api";
    public static final String URL_INSERT = "http://192.168.43.72/Minggu14/Mahasiswa/ApiInsert";
    public static final String URL_DELETE = "http://192.168.43.72/Minggu14/Mahasiswa/ApiDelete";
    public static final String URL_UPDATE = "http://192.168.43.72/Minggu14/Mahasiswa/ApiUpdate";
}
